create_project native_system {/home/work1/tmp/codex-ai-gain44-20261014-9a549d2/green-simulation-paths/modes/project} -part xcku5p-ffvb676-2-e -force
set_property target_language VHDL [current_project]
set_property simulator_language Mixed [current_project]
set_property XPM_LIBRARIES {XPM_CDC XPM_MEMORY XPM_FIFO} [current_project]
source {/home/work1/tmp/codex-ai-gain44-20261014-9a549d2/green-simulation-paths/modes/sources.tcl}
add_files -fileset sim_1 {/home/work1/tmp/codex-ai-gain44-20261014-9a549d2/src/tests/tb_native_modes.sv}
set_property top tb_native_modes [get_filesets sim_1]
set_property xsim.simulate.runtime all [get_filesets sim_1]
set_property -name xsim.simulate.xsim.more_options -value {-testplusarg REFERENCE=/home/work1/tmp/codex-ai-gain44-20261014-9a549d2/reference -testplusarg WINDOWS=1096 -testplusarg OVERLOAD=0 -testplusarg GAP=0 -testplusarg PHASE=0 -testplusarg THRESHOLD=00000000} -objects [get_filesets sim_1]
update_compile_order -fileset sources_1
update_compile_order -fileset sim_1
launch_simulation
close_sim
close_project
exit
