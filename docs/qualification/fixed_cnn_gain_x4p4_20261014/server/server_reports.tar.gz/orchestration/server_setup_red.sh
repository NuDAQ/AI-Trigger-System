#!/usr/bin/env bash
set -uo pipefail
task_root=/home/work1/tmp/codex-ai-gain44-20261014-9a549d2
source_root=/home/work1/tmp/codex-score-v4-20261013-edcb9a6-4cac4f
export PATH="/home/work1/.cargo/bin:$PATH"
mkdir -p "$task_root/src"
tar -xf "$task_root/ai-source.tar" -C "$task_root/src"
cd "$task_root/src"
cat > Bender.local <<EOF
overrides:
  cnn-core-wrapper: { path: "$source_root/deps/CNN-Core-Wrapper" }
  cnn-core: { path: "$source_root/deps/CNN-Core-Generator" }
  hilo-trigger: { path: "$source_root/deps/Hi-Lo-Trigger" }
EOF
bender update || exit 1
python3 scripts/build_native_reference.py --core-root "$source_root/deps/CNN-Core-Generator" \
 --npz /home/work1/tmp/codex-gateware-v401-20261013-34436d4/verification_data_v6_2cv_k5s3_f12_amphp.npz \
 --hls-include /tools/Xilinx/Vitis_HLS/2022.2/include --output "$task_root/reference" || exit 1
python3 scripts/run_native_qualification.py --vivado /tools/Xilinx/Vivado/2022.2/bin/vivado \
 --reference "$task_root/reference" --output "$task_root/red-modes" --cases modes
result=$?
printf '%s\n' "$result" > "$task_root/red_exit_code.txt"
exit 0
