set ::env(PATH) /home/work1/tmp/codex-ai-gain44-20261014-9a549d2/bin:$::env(PATH)
puts "TASK_BENDER=[exec which bender]"
puts "TASK_BENDER_VERSION=[exec /home/work1/tmp/codex-ai-gain44-20261014-9a549d2/bin/bender --version]"
set ::RUN_BUILD_REPO_ROOT {/home/work1/tmp/codex-ai-gain44-20261014-9a549d2/src}
set ::RUN_BUILD_OUT_DIR {/home/work1/tmp/codex-ai-gain44-20261014-9a549d2/ooc-runtime}
set ::RUN_BUILD_PART xcku5p-ffvb676-2-e
set ::RUN_BUILD_TOP AI_TRIGGER_TOP
set ::RUN_BUILD_IMPL 1
set ::RUN_BUILD_THREADS 4
set ::RUN_BUILD_MIN_SETUP_SLACK 0.0
source {/home/work1/tmp/codex-ai-gain44-20261014-9a549d2/src/scripts/vivado_ooc_build.tcl}
exit
