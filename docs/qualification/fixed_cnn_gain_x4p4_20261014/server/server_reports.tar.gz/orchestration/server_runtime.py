from pathlib import Path
import shutil
root=Path('/home/work1/tmp/codex-ai-gain44-20261014-9a549d2');src=root/'src';base=root/'old-threshold-src';base.mkdir(exist_ok=True)
for directory in ['HDL','scripts']:shutil.copytree(src/directory,base/directory,dirs_exist_ok=True)
(base/'tests').mkdir(exist_ok=True)
bench=(src/'tests/tb_native_modes.sv').read_text().replace('run_mode(4, 281, 1); run_mode(4, 282, 0);','run_mode(4, 529, 1); run_mode(4, 530, 0);')
(base/'tests/tb_native_modes.sv').write_text(bench)
for name in ['Bender.yml','Bender.lock','Bender.local']:shutil.copy2(src/name,base/name)
(root/'ooc-runtime.tcl').write_text(f"""set ::env(PATH) {root}/bin:$::env(PATH)
puts \"TASK_BENDER=[exec which bender]\"
puts \"TASK_BENDER_VERSION=[exec {root}/bin/bender --version]\"
set ::RUN_BUILD_REPO_ROOT {{{src}}}
set ::RUN_BUILD_OUT_DIR {{{root}/ooc-runtime}}
set ::RUN_BUILD_PART xcku5p-ffvb676-2-e
set ::RUN_BUILD_TOP AI_TRIGGER_TOP
set ::RUN_BUILD_IMPL 1
set ::RUN_BUILD_THREADS 4
set ::RUN_BUILD_MIN_SETUP_SLACK 0.0
source {{{src}/scripts/vivado_ooc_build.tcl}}
exit
""")
