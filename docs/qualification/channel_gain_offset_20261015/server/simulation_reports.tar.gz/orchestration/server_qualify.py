from pathlib import Path
import hashlib,json,os,subprocess,sys
root=Path('/home/work1/tmp/codex-channel-calibration-20261015-526a78d')
src=root/'src';out=root/'qualification';out.mkdir(exist_ok=True)
os.environ['PATH']=str(root/'bin')+':'+os.environ['PATH']
def run(stage,cmd):
    with (root/(stage+'.log')).open('w') as log:
        p=subprocess.run(cmd,cwd=src,stdout=log,stderr=subprocess.STDOUT)
    (root/(stage+'.exit')).write_text(str(p.returncode)+'\n')
    if p.returncode:raise SystemExit(stage+' failed: '+str(p.returncode))
sys.path.insert(0,str(src/'scripts'))
from source_manifest import capture
capture(src,out,['vivado','simulation'])
local=json.loads((root/'source_manifest.json').read_text())
remote=json.loads((out/'source_manifest.json').read_text())
index=lambda d:{(v['package'],v['file']):v['sha256'] for v in d['files']}
assert index(local)==index(remote),'local/server resolved source mismatch'
run('reference',['python3',str(src/'scripts/build_native_reference.py'),'--core-root','/home/work1/tmp/codex-score-v4-20261013-edcb9a6-4cac4f/deps/CNN-Core-Generator','--npz','/home/work1/tmp/codex-score-v4-20261013-edcb9a6-4cac4f/deps/CNN-Core-Generator/models/amphp_oct_12/verification_data_v6_2cv_k5s3_f12_amphp.npz','--hls-include','/tools/Xilinx/Vitis_HLS/2022.2/include','--output',str(root/'reference')])
a=json.loads((root/'reference.json').read_text());b=json.loads((root/'reference/reference.json').read_text())
assert a['files']==b['files'],'server original-header reference differs from local'
(out/'reference_parity.json').write_text(json.dumps({'all_data_hashes_match':True,'files':a['files']},indent=2)+'\n')
run('simulation',['python3',str(src/'scripts/run_native_qualification.py'),'--reference',str(root/'reference'),'--output',str(root/'simulation'),'--vivado','/tools/Xilinx/Vivado/2022.2/bin/vivado'])
(root/'ooc-runtime.tcl').write_text('set ::env(PATH) '+str(root/'bin')+':$::env(PATH)\n'+
    '\n'.join('set ::'+k+' {'+str(v)+'}' for k,v in {'RUN_BUILD_REPO_ROOT':src,'RUN_BUILD_OUT_DIR':root/'ooc','RUN_BUILD_PART':'xcku5p-ffvb676-2-e','RUN_BUILD_TOP':'AI_TRIGGER_TOP','RUN_BUILD_IMPL':1,'RUN_BUILD_THREADS':4,'RUN_BUILD_MIN_SETUP_SLACK':0.0}.items())+
    '\nsource {'+str(src/'scripts/vivado_ooc_build.tcl')+'}\nexit\n')
run('ooc',['/tools/Xilinx/Vivado/2022.2/bin/vivado','-mode','batch','-source',str(root/'ooc-runtime.tcl'),'-log',str(root/'ooc-vivado.log'),'-journal',str(root/'ooc-vivado.jou')])
(root/'SUCCESS').write_text('reference, nine real-XPM cases and routed OOC passed\n')
